function App() {
  return (
    <main className="app-shell">
      <section className="hero" aria-labelledby="page-title">
        <p className="eyebrow">Interactive learning prototype</p>
        <h1 id="page-title">Professional Interactions</h1>
        <p className="subtitle">An interactive Code of Conduct learning prototype</p>
        <button type="button">Begin scenario</button>
      </section>
    </main>
  )
}

export default App
